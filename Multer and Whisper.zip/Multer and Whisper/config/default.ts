export default {
    port: "5000",
    dbUri: "mongodb://localhost:27017/mydatabase",
    saltWorkFactor:10
}